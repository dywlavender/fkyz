from __future__ import annotations

import hashlib
import json
import os
import re
import time
from pathlib import Path

from .api_docs import list_api_docs
from .business_rules import business_rules_fingerprint
from .paths import OUTPUTS_DIR
from .utils import atomic_write_text, parse_frontmatter, read_text

STANDARD_JSON_SCHEMA_VERSION = "risk_review_standard_json_v2"

STANDARD_DIMENSIONS = {
    "D1": {
        "heading": "因子加工输入字段",
        "key": "inputs",
        "dimension": "input_completeness",
    },
    "D2": {
        "heading": "字段溯源",
        "key": "field_lineage",
        "dimension": "logic_consistency",
    },
    "D3": {
        "heading": "过滤条件",
        "key": "filters",
        "dimension": "logic_consistency",
    },
    "D4": {
        "heading": "列表/数组字段处理",
        "key": "array_handling",
        "dimension": "logic_consistency",
    },
    "D5": {
        "heading": "计算逻辑",
        "key": "calculation",
        "dimension": "logic_consistency",
    },
    "D6": {
        "heading": "默认值兜底策略",
        "key": "default_strategy",
        "dimension": "logic_consistency",
    },
    "D7": {
        "heading": "因子输出字段",
        "key": "output_fields",
        "dimension": "logic_consistency",
    },
    "D8": {
        "heading": "比率/衍生因子计算",
        "key": "ratio_or_derivation",
        "dimension": "logic_consistency",
    },
    "D9": {
        "heading": "条件分支逻辑",
        "key": "conditional_branches",
        "dimension": "logic_consistency",
    },
}

STANDARD_JSON_TOP_LEVEL_FIELDS = {
    "schema_version",
    "factor_name",
    "inputs",
    "field_lineage",
    "filters",
    "array_handling",
    "calculation",
    "default_strategy",
    "output_fields",
    "ratio_or_derivation",
    "conditional_branches",
    "unknown_register",
    "open_questions",
    "source_metadata",
    "rules",
}

STANDARD_RULE_REQUIRED_FIELDS = {
    "rule_id",
    "dimension",
    "standard_level",
    "basis_type",
    "basis_text",
    "source_section",
    "dimension_ref",
    "evidence_ids",
    "content",
}


STANDARD_DIGEST_HEADINGS = [
    "0. 输入解析",
    "因子加工输入字段",
    "字段溯源",
    "过滤条件",
    "列表/数组字段处理",
    "计算逻辑",
    "默认值兜底策略",
    "因子输出字段",
    "比率/衍生因子计算",
    "条件分支逻辑",
    "Unknown Register",
]


def read_phase1_standard(payload: dict) -> tuple[str, Path]:
    standard_file_id = (payload.get("standardFileId") or "").strip()
    if not standard_file_id:
        raise ValueError("Phase 1 标准文件 ID 不能为空。")
    std_path = OUTPUTS_DIR / standard_file_id
    if not std_path.exists():
        raise FileNotFoundError(f"Phase 1 标准文件未找到：{standard_file_id}")
    standard_text = read_text(std_path)
    meta = parse_frontmatter(standard_text)
    stored_checksum = meta.get("input_checksum")
    current_checksum = compute_phase1_checksum(payload)
    if not stored_checksum or stored_checksum == "<external-sha256-required>":
        raise ValueError("Phase 1 标准文件缺少 input_checksum，请重新执行 Phase 1。")
    if stored_checksum != current_checksum:
        raise ValueError(
            "输入已变更（checksum 不匹配），请重新执行 Phase 1。"
            f" stored={stored_checksum[:8]}..., current={current_checksum[:8]}..."
        )
    stored_public_rules_checksum = meta.get("public_rules_checksum")
    current_public_rules_checksum = compute_public_rules_checksum()
    if not stored_public_rules_checksum:
        raise ValueError("Phase 1 标准文件缺少 public_rules_checksum，请重新执行 Phase 1。")
    if stored_public_rules_checksum != current_public_rules_checksum:
        raise ValueError(
            "公共业务知识规则已变更（checksum 不匹配），请重新执行 Phase 1。"
            f" stored={stored_public_rules_checksum[:8]}..., current={current_public_rules_checksum[:8]}..."
        )
    return standard_text, std_path


def strip_yaml_frontmatter(text: str) -> str:
    return re.sub(r"^---\n[\s\S]*?\n---\s*", "", str(text), count=1).strip()


def normalize_markdown_document_body(text: str, required_heading: str | None = None) -> str:
    body = str(text or "").strip()
    fenced_blocks = list(re.finditer(r"```(?:markdown|md)?[ \t]*\n([\s\S]*?)\n```", body, re.I))
    for block in fenced_blocks:
        inner = block.group(1).strip()
        if not required_heading or inner.startswith(required_heading):
            body = inner
            break

    if required_heading and not body.startswith(required_heading):
        heading_match = re.search(rf"^{re.escape(required_heading)}\b.*$", body, re.M)
        if heading_match:
            body = body[heading_match.start():].strip()

    body = re.sub(
        r"\n+(?:已保存|文件已保存至)[：:]\s*outputs/[^\n]+\.md\s*$",
        "",
        body,
    ).strip()
    return body


def extract_markdown_sections(text: str) -> dict[str, str]:
    body = strip_yaml_frontmatter(text)
    sections = {}
    matches = list(re.finditer(r"^##\s+(.+?)\s*$", body, re.M))
    for index, match in enumerate(matches):
        title = match.group(1).strip()
        start = match.start()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(body)
        sections[title] = body[start:end].strip()
    return sections


def build_standard_digest(standard_text: str) -> str:
    meta = parse_frontmatter(standard_text)
    sections = extract_markdown_sections(standard_text)
    lines = [
        "# 标准加工规范结构化摘要",
        "",
        "## 元信息",
        f"- 因子名：{meta.get('factor_name', '未提供')}",
        f"- 标准文件 checksum：{meta.get('input_checksum', '未提供')}",
        "",
        "## 评审依据",
        "以下内容由 Phase 1 标准规范抽取而来，保留 Phase 2 逐项评审所需字段、码值、过滤条件、计算步骤和兜底口径。",
    ]
    for heading in STANDARD_DIGEST_HEADINGS:
        section = sections.get(heading)
        if section:
            lines.extend(["", section])
    digest = "\n".join(lines).strip()
    max_chars = int(os.environ.get("RISK_REVIEW_STANDARD_DIGEST_MAX_CHARS", "18000"))
    if len(digest) > max_chars:
        digest = digest[:max_chars] + "\n\n[摘要截断：标准规范过长，仅保留前部关键结构。]"
    return digest


def extract_section_text(sections: dict[str, str], heading: str) -> str:
    return sections.get(heading, "").strip()

def canonical_json_dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def compute_public_rules_checksum() -> str:
    return hashlib.sha256(canonical_json_dumps(business_rules_fingerprint()).encode("utf-8")).hexdigest()


def _strip_standard_json_checksum(summary: dict) -> dict:
    copied = json.loads(json.dumps(summary, ensure_ascii=False))
    source_metadata = copied.get("source_metadata")
    if isinstance(source_metadata, dict):
        source_metadata.pop("standard_json_checksum", None)
    return copied


def compute_standard_json_checksum(summary: dict) -> str:
    return hashlib.sha256(
        canonical_json_dumps(_strip_standard_json_checksum(summary)).encode("utf-8")
    ).hexdigest()


def update_frontmatter_fields(text: str, fields: dict[str, str]) -> str:
    text = str(text)
    if not text.startswith("---\n"):
        lines = ["---", *[f"{key}: {value}" for key, value in fields.items()], "---", "", text]
        return "\n".join(lines)
    match = re.match(r"^---\n(?P<meta>[\s\S]*?)\n---\s*", text)
    if not match:
        return text
    meta_lines = match.group("meta").splitlines()
    remaining = text[match.end():]
    existing: dict[str, int] = {}
    for index, line in enumerate(meta_lines):
        key = line.split(":", 1)[0].strip() if ":" in line else ""
        if key:
            existing[key] = index
    for key, value in fields.items():
        rendered = f"{key}: {value}"
        if key in existing:
            meta_lines[existing[key]] = rendered
        else:
            meta_lines.append(rendered)
    return "---\n" + "\n".join(meta_lines).rstrip() + "\n---\n\n" + remaining.lstrip()


def split_markdown_table(row: str) -> list[str]:
    row = row.strip()
    if row.startswith("|"):
        row = row[1:]
    if row.endswith("|"):
        row = row[:-1]
    return [cell.strip() for cell in row.split("|")]


def extract_markdown_tables(section_text: str) -> list[dict[str, list[dict[str, str]]]]:
    tables = []
    lines = section_text.splitlines()
    index = 0
    while index < len(lines) - 1:
        header_line = lines[index].strip()
        separator_line = lines[index + 1].strip()
        if not (header_line.startswith("|") and separator_line.startswith("|")):
            index += 1
            continue
        separator_cells = split_markdown_table(separator_line)
        if not separator_cells or not all(re.fullmatch(r":?-{3,}:?", cell.strip()) for cell in separator_cells):
            index += 1
            continue
        headers = split_markdown_table(header_line)
        rows = []
        index += 2
        while index < len(lines) and lines[index].strip().startswith("|"):
            cells = split_markdown_table(lines[index])
            if len(cells) < len(headers):
                cells.extend([""] * (len(headers) - len(cells)))
            rows.append({header: cells[pos].strip() for pos, header in enumerate(headers)})
            index += 1
        tables.append({"headers": headers, "rows": rows})
    return tables


def infer_standard_level(text: str) -> str:
    text = text or ""
    if re.search(r"建议|建议口径|非阻断|\bsuggestion\b", text, re.I):
        return "suggestion"
    if re.search(r"待确认|未明确|疑问|不适用：原始依据未明确|评审阶段确认|\bunclear\b", text, re.I):
        return "unclear"
    if re.search(r"\bhard\b", text, re.I):
        return "hard"
    return "hard"


def infer_basis_type(text: str, standard_level: str) -> str:
    text = text or ""
    if standard_level == "suggestion":
        return "unbased_suggestion"
    if "公共业务知识" in text or "公共规则" in text or re.search(r"\brule-[0-9a-fA-F]+", text):
        return "public_rule"
    if "需求" in text:
        return "requirement"
    if "确定性推导" in text or "推导" in text:
        return "deterministic_inference"
    if "接口" in text or "字段" in text:
        return "api_doc"
    return "deterministic_inference" if standard_level == "hard" else "unbased_suggestion"


def row_to_rule_content(row: dict[str, str]) -> str:
    parts = []
    for key, value in row.items():
        if value:
            parts.append(f"{key}: {value}")
    return "；".join(parts).strip()


def extract_basis_text(row: dict[str, str], section_text: str, content: str) -> str:
    for key in ("证据锚点", "依据", "需求依据", "来源说明", "备注"):
        if row.get(key):
            return row[key].strip()
    for line in section_text.splitlines():
        if "依据" in line or "证据" in line:
            clean = line.strip(" |")
            if clean and "---" not in clean:
                return clean[:500]
    return content[:500]


def extract_public_rule_ids(text: str) -> list[str]:
    return sorted(set(re.findall(r"\brule-[0-9a-zA-Z_-]+", text or "")))


def extract_evidence_ids(text: str) -> list[str]:
    return sorted(set(re.findall(r"\b(?:REQ|API|PUB|INF)-\d{3}\b", text or "")))


def extract_field_paths(text: str) -> list[str]:
    candidates = set(re.findall(r"`([^`]+)`", text or ""))
    candidates.update(re.findall(r"[\u4e00-\u9fffA-Za-z0-9_]+(?:接口)?(?:\.[A-Za-z_][A-Za-z0-9_]*|\[\])+(?:\.[A-Za-z_][A-Za-z0-9_]*|\[\])*", text or ""))
    candidates.update(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\[\](?:\.[A-Za-z_][A-Za-z0-9_]*)*\b", text or ""))
    return sorted(item for item in candidates if item and len(item) <= 120)


def build_rules_for_section(dimension_ref: str, section_text: str) -> list[dict]:
    config = STANDARD_DIMENSIONS[dimension_ref]
    heading = config["heading"]
    rules = []
    tables = extract_markdown_tables(section_text)
    row_index = 1
    for table in tables:
        for row in table["rows"]:
            content = row_to_rule_content(row)
            if not content or re.fullmatch(r"[-—/\\\s]+", content):
                continue
            standard_level = infer_standard_level(content)
            basis_text = extract_basis_text(row, section_text, content)
            basis_type = infer_basis_type(content + "\n" + basis_text, standard_level)
            rule = {
                "rule_id": f"{dimension_ref}-{row_index:03d}",
                "dimension": config["dimension"],
                "standard_level": standard_level,
                "basis_type": basis_type,
                "basis_text": basis_text,
                "source_section": heading,
                "dimension_ref": dimension_ref,
                "evidence_ids": extract_evidence_ids(content + "\n" + basis_text),
                "public_rule_ids": extract_public_rule_ids(content + "\n" + basis_text),
                "field_paths": extract_field_paths(content),
                "content": content,
            }
            rules.append(rule)
            row_index += 1
    if not rules and section_text.strip():
        content = "\n".join(
            line.strip()
            for line in section_text.splitlines()
            if line.strip() and not line.strip().startswith("##")
        ).strip()
        if content:
            standard_level = infer_standard_level(content)
            rules.append({
                "rule_id": f"{dimension_ref}-001",
                "dimension": config["dimension"],
                "standard_level": standard_level,
                "basis_type": infer_basis_type(content, standard_level),
                "basis_text": content[:500],
                "source_section": heading,
                "dimension_ref": dimension_ref,
                "evidence_ids": extract_evidence_ids(content),
                "public_rule_ids": extract_public_rule_ids(content),
                "field_paths": extract_field_paths(content),
                "content": content,
            })
    return rules


def extract_open_questions(sections: dict[str, str]) -> list[dict]:
    questions = []
    seen = set()
    for dimension_ref, config in STANDARD_DIMENSIONS.items():
        section_text = extract_section_text(sections, config["heading"])
        for match in re.finditer(r"\[(疑问\d+)\]\s*([^|\n]*)", section_text):
            question_id = match.group(1)
            if question_id in seen:
                continue
            seen.add(question_id)
            questions.append({
                "id": question_id,
                "dimension_ref": dimension_ref,
                "source_section": config["heading"],
                "content": (match.group(2) or "").strip() or match.group(0),
            })
    return questions


def extract_unknown_register(sections: dict[str, str]) -> list[dict]:
    unknowns = []
    section_text = extract_section_text(sections, "Unknown Register")
    for table in extract_markdown_tables(section_text):
        for row in table["rows"]:
            unknown_id = (
                row.get("Unknown ID")
                or row.get("未知项编号")
                or row.get("疑问编号")
                or ""
            ).strip()
            if not unknown_id:
                continue
            unknowns.append({
                "unknown_id": unknown_id,
                "dimension_ref": next(iter(re.findall(r"U-(D\d+)-\d{3}", unknown_id)), ""),
                "trigger": row.get("触发位置", "").strip(),
                "content": (row.get("未知内容") or row.get("疑问内容") or "").strip(),
                "reason": row.get("原因", "").strip(),
                "impact": row.get("影响", "").strip(),
                "handling": row.get("处理方式", "").strip(),
            })
    return unknowns


def validate_standard_json_summary(summary: dict) -> None:
    if not isinstance(summary, dict):
        raise ValueError("结构化标准 JSON 格式无效。")
    if summary.get("schema_version") != STANDARD_JSON_SCHEMA_VERSION:
        raise ValueError("结构化标准 JSON schema_version 不是 risk_review_standard_json_v2，请重新执行 Phase 1。")
    missing = sorted(field for field in STANDARD_JSON_TOP_LEVEL_FIELDS if field not in summary)
    if missing:
        raise ValueError(f"结构化标准 JSON 缺少顶层字段：{', '.join(missing)}")
    rules = summary.get("rules")
    if not isinstance(rules, list) or not rules:
        raise ValueError("结构化标准 JSON 缺少可评审 rules，请重新执行 Phase 1 摘要抽取。")
    valid_dimension_refs = set(STANDARD_DIMENSIONS)
    for index, rule in enumerate(rules, start=1):
        if not isinstance(rule, dict):
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则格式无效。")
        missing_rule_fields = sorted(field for field in STANDARD_RULE_REQUIRED_FIELDS if field not in rule)
        if missing_rule_fields:
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则缺少字段：{', '.join(missing_rule_fields)}")
        if rule.get("dimension") not in {"input_completeness", "logic_consistency"}:
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则 dimension 无效。")
        if rule.get("standard_level") not in {"hard", "unclear", "suggestion"}:
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则 standard_level 无效。")
        if rule.get("basis_type") not in {
            "requirement",
            "api_doc",
            "public_rule",
            "deterministic_inference",
            "unbased_suggestion",
        }:
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则 basis_type 无效。")
        if rule.get("dimension_ref") not in valid_dimension_refs:
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则 dimension_ref 无效。")
        if not isinstance(rule.get("evidence_ids"), list):
            raise ValueError(f"结构化标准 JSON 第 {index} 条规则 evidence_ids 无效。")
    validate_hard_logic_dependencies(summary)


def validate_phase1_standard_output(standard_text: str) -> None:
    body = strip_yaml_frontmatter(standard_text)
    if not re.search(r"^#\s+标准加工规范\b", body, re.M):
        raise ValueError("Claude 未输出完整 Phase 1 标准加工规范正文，stdout 必须以「# 标准加工规范」开头。")
    summary = build_standard_json_summary(standard_text)
    validate_standard_json_summary(summary)
    validate_hard_logic_dependencies(summary)


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", "", str(value or ""))


def _rule_mentions_other_rule(rule: dict, target_rule_id: str) -> bool:
    text = f"{rule.get('content') or ''}\n{rule.get('basis_text') or ''}"
    return bool(re.search(rf"\b{re.escape(target_rule_id)}\b", text))


def _is_time_window_rule(rule: dict) -> bool:
    if rule.get("dimension_ref") not in {"D3", "D4", "D5"}:
        return False
    text = f"{rule.get('content') or ''}\n{rule.get('basis_text') or ''}"
    return any(token in text for token in ("时间窗口", "窗口起点", "窗口终点", "进件时点", "kprq", "kpyf", "日期", "月份"))


def _contains_unresolved_marker(text: str) -> bool:
    compact = _normalize_text(text)
    unresolved_markers = (
        "待确认",
        "未明确",
        "原始依据未明确",
        "需确认",
        "不适用：原始依据未明确",
        "无法确定",
        "未定位",
        "未找到",
    )
    return any(marker in compact for marker in unresolved_markers)


def _extract_boundary_table_map(filters_text: str) -> dict[str, str]:
    for table in extract_markdown_tables(filters_text):
        headers = table.get("headers") or []
        if headers[:2] != ["项目", "内容"]:
            continue
        mapping = {}
        for row in table.get("rows") or []:
            key = str(row.get("项目") or "").strip()
            value = str(row.get("内容") or "").strip()
            if key:
                mapping[key] = value
        if any(key in mapping for key in ("基准时间点", "时间窗口粒度", "窗口起点计算规则", "窗口终点计算规则", "包含边界说明")):
            return mapping
    return {}


def _rule_requires_time_window_closure(rule: dict) -> bool:
    if rule.get("standard_level") != "hard":
        return False
    if not _is_time_window_rule(rule):
        return False
    text = f"{rule.get('content') or ''}\n{rule.get('basis_text') or ''}"
    if _contains_unresolved_marker(text):
        return False
    return True


def _boundary_value_has_structural_signal(label: str, value: str) -> bool:
    compact = _normalize_text(value)
    if not compact or _contains_unresolved_marker(compact):
        return False
    if label == "基准时间点":
        return bool(extract_field_paths(value))
    if label == "时间窗口粒度":
        return any(token in compact for token in ("日", "天", "月", "自然月", "年", "季度"))
    if label in {"窗口起点计算规则", "窗口终点计算规则"}:
        has_formula = any(token in value for token in (">=", "<=", ">", "<", "=", "+", "-", "[", "]", "(", ")", "前", "后"))
        has_reference = bool(extract_field_paths(value)) or any(token in compact for token in ("进件时点", "申请时点", "申请月份", "基准时间点", "窗口起点", "窗口终点", "月初", "月末"))
        return has_formula or has_reference
    if label == "包含边界说明":
        return any(token in compact for token in ("包含", "不包含", "闭区间", "开区间", ">=<=", "><", "含"))
    return True


def validate_hard_logic_dependencies(summary: dict) -> None:
    rules = summary.get("rules") or []
    unclear_filter_rules = [
        rule for rule in rules
        if rule.get("dimension_ref") == "D3" and rule.get("standard_level") == "unclear"
    ]
    hard_logic_rules = [
        rule for rule in rules
        if rule.get("dimension_ref") in {"D4", "D5", "D7"} and rule.get("standard_level") == "hard"
    ]

    for unclear_rule in unclear_filter_rules:
        for hard_rule in hard_logic_rules:
            if _rule_mentions_other_rule(hard_rule, str(unclear_rule.get("rule_id"))):
                raise ValueError(
                    "Phase 1 标准存在主链断裂：过滤条件为 unclear，但下游列表/计算/输出规则仍以 hard 依赖该过滤条件。"
                    f" unclear={unclear_rule.get('rule_id')} -> hard={hard_rule.get('rule_id')}"
                )

    filters_text = str(summary.get("filters") or "")
    time_window_hard_rules = [rule for rule in rules if _rule_requires_time_window_closure(rule)]
    if not time_window_hard_rules:
        return

    boundary_map = _extract_boundary_table_map(filters_text)
    required_labels = ["基准时间点", "时间窗口粒度", "窗口起点计算规则", "窗口终点计算规则", "包含边界说明"]
    missing = [label for label in required_labels if label not in boundary_map]
    if missing:
        raise ValueError(
            "Phase 1 标准的 hard 时间窗口规则缺少必要口径："
            + "、".join(missing)
        )

    invalid = [
        label for label in required_labels
        if not _boundary_value_has_structural_signal(label, boundary_map.get(label, ""))
    ]
    if invalid:
        raise ValueError(
            "Phase 1 标准的 hard 时间窗口规则口径不完整或不可验证："
            + "、".join(invalid)
        )


def build_standard_json_summary(standard_text: str) -> dict:
    meta = parse_frontmatter(standard_text)
    sections = extract_markdown_sections(standard_text)
    rules = []
    section_payloads = {}
    for dimension_ref, config in STANDARD_DIMENSIONS.items():
        section_text = extract_section_text(sections, config["heading"])
        section_payloads[config["key"]] = section_text
        rules.extend(build_rules_for_section(dimension_ref, section_text))
    source_metadata = {
        "phase": meta.get("phase", "1"),
        "factor_slug": meta.get("factor_slug", ""),
        "generated": meta.get("generated", ""),
        "input_checksum": meta.get("input_checksum", ""),
        "public_rules_checksum": meta.get("public_rules_checksum") or compute_public_rules_checksum(),
        "standard_json_checksum": "",
        "business_rules_fingerprint": business_rules_fingerprint(),
        "dimension_map": {
            dimension_ref: config["heading"]
            for dimension_ref, config in STANDARD_DIMENSIONS.items()
        },
    }
    summary = {
        "schema_version": STANDARD_JSON_SCHEMA_VERSION,
        "factor_name": meta.get("factor_name", ""),
        "input_parse": extract_section_text(sections, "0. 输入解析"),
        "inputs": section_payloads["inputs"],
        "field_lineage": section_payloads["field_lineage"],
        "filters": section_payloads["filters"],
        "array_handling": section_payloads["array_handling"],
        "calculation": section_payloads["calculation"],
        "default_strategy": section_payloads["default_strategy"],
        "output_fields": section_payloads["output_fields"],
        "ratio_or_derivation": section_payloads["ratio_or_derivation"],
        "conditional_branches": section_payloads["conditional_branches"],
        "unknown_register": extract_unknown_register(sections),
        "open_questions": extract_open_questions(sections),
        "source_metadata": source_metadata,
        "rules": rules,
    }
    summary["source_metadata"]["standard_json_checksum"] = compute_standard_json_checksum(summary)
    return summary


def save_standard_json_summary(standard_file_id: str, standard_text: str) -> str:
    summary = build_standard_json_summary(standard_text)
    validate_standard_json_summary(summary)
    summary_name = standard_file_id.replace(".md", ".summary.json")
    OUTPUTS_DIR.mkdir(exist_ok=True)
    atomic_write_text(OUTPUTS_DIR / summary_name, json.dumps(summary, ensure_ascii=False, indent=2))
    standard_path = OUTPUTS_DIR / standard_file_id
    if standard_path.exists():
        updated_text = update_frontmatter_fields(
            read_text(standard_path),
            {
                "public_rules_checksum": summary["source_metadata"]["public_rules_checksum"],
                "standard_json_checksum": summary["source_metadata"]["standard_json_checksum"],
            },
        )
        atomic_write_text(standard_path, updated_text)
    return summary_name


def extract_saved_output_file(stdout: str, prefix: str, suffix: str = ".md") -> str | None:
    patterns = [
        rf"outputs/({re.escape(prefix)}[^`\s，。；;）)]+{re.escape(suffix)})",
        rf"已保存[：:]\s*outputs/({re.escape(prefix)}[^`\s，。；;）)]+{re.escape(suffix)})",
        rf"文件已保存至[：:]\s*outputs/({re.escape(prefix)}[^`\s，。；;）)]+{re.escape(suffix)})",
    ]
    for pattern in patterns:
        match = re.search(pattern, stdout or "")
        if match:
            name = Path(match.group(1)).name
            if (OUTPUTS_DIR / name).exists():
                return name
    candidates = sorted(OUTPUTS_DIR.glob(f"{prefix}*{suffix}"), key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0].name if candidates else None


def standard_summary_name_for(standard_file_id: str) -> str:
    return standard_file_id.replace(".md", ".summary.json")


def build_phase1_frontmatter(
    payload: dict,
    slug: str,
    factor_name: str,
    checksum: str,
    mock: bool = False,
) -> str:
    requirement = (payload.get("requirement") or "").strip()
    api_names = payload.get("apiNames") or []
    api_names = [str(x).strip() for x in api_names if str(x).strip()]
    return "\n".join([
        "---",
        "phase: 1",
        f"factor_slug: {slug}",
        f"factor_name: {factor_name}",
        f"generated: {time.strftime('%Y-%m-%d')}",
        f"input_checksum: {checksum}",
        f"public_rules_checksum: {compute_public_rules_checksum()}",
        f"mock: {'true' if mock else 'false'}",
        "input_summary:",
        f"  requirement: {requirement[:120]}",
        f"  api_docs: [{', '.join(api_names)}]",
        "---",
        "",
    ])


def normalize_phase1_output(
    output_text: str,
    payload: dict,
    slug: str,
    factor_name: str,
    checksum: str,
    mock: bool = False,
) -> str:
    body = strip_yaml_frontmatter(output_text)
    body = normalize_markdown_document_body(body, required_heading="# 标准加工规范")
    return build_phase1_frontmatter(
        payload,
        slug,
        factor_name,
        checksum,
        mock=mock,
    ) + body


def build_review_frontmatter(payload: dict, slug: str, standard_file_id: str, checksum: str) -> str:
    return "\n".join([
        "---",
        "phase: 2",
        f"factor_slug: {slug}",
        f"standard_file: {standard_file_id}",
        f"generated: {time.strftime('%Y-%m-%d')}",
        f"review_checksum: {checksum}",
        "---",
        "",
    ])


def compute_review_checksum(payload: dict, standard_summary: dict | None = None) -> str:
    raw = json.dumps({
        "factorName": (payload.get("factorName") or "").strip(),
        "draft": (payload.get("draft") or "").strip(),
        "standardFileId": (payload.get("standardFileId") or "").strip(),
        "standardSummary": standard_summary or {},
        "businessRules": business_rules_fingerprint(),
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def normalize_review_output(output_text: str, payload: dict, slug: str, standard_file_id: str, checksum: str) -> str:
    body = strip_yaml_frontmatter(output_text)
    body = normalize_markdown_document_body(body, required_heading="# 评审报告")
    return build_review_frontmatter(payload, slug, standard_file_id, checksum) + body


def compute_phase1_checksum(payload: dict) -> str:
    factor_name = (payload.get("factorName") or "").strip()
    requirement = (payload.get("requirement") or "").strip()
    api_names = sorted([str(x).strip() for x in (payload.get("apiNames") or []) if str(x).strip()])
    api_lookup = {doc["name"]: doc for doc in list_api_docs(include_content=True)}
    api_fingerprints = []
    for name in api_names:
        doc = api_lookup.get(name)
        if doc:
            api_fingerprints.append({
                "name": doc.get("name", ""),
                "path": doc.get("path", ""),
                "sha256": doc.get("content_sha256", ""),
            })
        else:
            api_fingerprints.append({"name": name, "missing": True})
    raw = json.dumps({
        "factorName": factor_name,
        "requirement": requirement,
        "apiDocs": api_fingerprints,
        "businessRules": business_rules_fingerprint(),
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def find_cached_phase1_standard(checksum: str, allow_mock: bool = False) -> dict | None:
    if not checksum or not OUTPUTS_DIR.exists():
        return None
    candidates = sorted(OUTPUTS_DIR.glob("standard-*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in candidates:
        try:
            text = read_text(path)
        except Exception:
            continue
        meta = parse_frontmatter(text)
        looks_like_mock = str(meta.get("mock", "false")).lower() == "true" or re.search(r"\bMock\b|mockDate|mockAmount", text)
        if looks_like_mock and not allow_mock:
            continue
        if "## 因子加工输入字段" not in text:
            continue
        if "## 多接口数据关联" in text:
            continue
        if meta.get("input_checksum") != checksum:
            continue
        if meta.get("public_rules_checksum") != compute_public_rules_checksum():
            continue
        if not meta.get("standard_json_checksum"):
            continue
        summary_file_id = path.name.replace(".md", ".summary.json")
        summary_path = OUTPUTS_DIR / summary_file_id
        if not summary_path.exists():
            continue
        try:
            summary = json.loads(read_text(summary_path))
            validate_standard_json_summary(summary)
            if compute_standard_json_checksum(summary) != meta.get("standard_json_checksum"):
                continue
        except Exception:
            continue
        return {
            "standardFileId": path.name,
            "standardSummaryFileId": summary_file_id,
            "stdout": text,
            "checksum": checksum,
            "cacheHit": True,
        }
    return None

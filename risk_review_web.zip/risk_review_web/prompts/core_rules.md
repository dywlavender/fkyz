# Rule Engine

## Rule Level

| Level | 含义 | Phase1 用法 | Phase2 用法 |
|---|---|---|---|
| hard | 有明确依据或确定性推导 | 写入标准规则 | 可作为不符合依据 |
| unclear | 未明确、待确认 | 写入 Unknown | 不作为问题依据 |
| suggestion | 非阻断建议 | 只作为建议 | 不作为问题依据 |

## Basis Type

| basis_type | 含义 |
|---|---|
| requirement | 需求内容 |
| api_doc | 接口文档 |
| public_rule | 公共业务规则 |
| deterministic_inference | 确定性推导 |
| unbased_suggestion | 无依据建议 |

## Rule JSON Contract

每条规则必须包含：

- `rule_id`
- `dimension_ref`
- `source_section`
- `standard_level`
- `basis_type`
- `evidence_ids`
- `content`

`standard_level = unclear` 和 `standard_level = suggestion` 不得作为 Phase2 的 `❌ 不符合` 依据。

---

# Evidence Engine

Evidence ID 按来源类型固定：

| Evidence 前缀 | 来源类型 |
|---|---|
| REQ | 需求内容 |
| API | 接口文档 |
| PUB | 公共业务知识规则 |
| INF | 确定性推导 |

排序规则：

1. 先需求内容。
2. 再接口文档。
3. 再公共规则。
4. 最后确定性推导。
5. 同类型按原文出现顺序编号。

凡写入 hard 的字段、枚举、过滤条件、时间窗口、聚合口径、单位换算、默认值兜底、条件分支，必须引用 Evidence ID 或等价证据锚点。

---

# Freeze Rule

| 冻结对象 | 生成阶段 | 冻结后限制 |
|---|---|---|
| INPUT_SET | STATE0 | 不得新增用户未提供的输入 |
| PUBLIC_RULE_SET | STATE1 | 不得新增公共规则 |
| API_DOC_SET | STATE2 | 不得新增接口文档 |
| FIELD_SET | STATE3 | 不得新增字段 |
| EVIDENCE_SET | STATE4 | 不得新增证据 |
| STANDARD_RULE_SET | STATE4 | 不得新增标准规则 |
| STRUCTURED_STANDARD_JSON | Phase2 STATE2 | 不得改写标准 JSON |
| REVIEWABLE_RULE_SET | Phase2 STATE3 | 不得新增可评审规则 |
| DRAFT_PARSE_SET | Phase2 STATE4 | 不得重新解释待评审输入 |
| ISSUE_SET | Phase2 STATE5 | 不得新增未判定问题 |

冻结后如发现需要新增字段、规则、证据或问题，不得直接新增，必须登记为 Unknown 或待确认。

---

# Hallucination Guard

以下内容如果没有来自需求内容、接口文档、公共业务知识规则或结构化标准 JSON 的明确依据，一律不得新增：

1. 新字段
2. 新接口
3. 新接口调用步骤
4. 新过滤条件
5. 新状态码
6. 新成功码
7. 新枚举值
8. 新默认值
9. 新兜底分支
10. 新时间窗口
11. 新边界条件
12. 新单位换算
13. 新精度
14. 新四舍五入方式
15. 新排序规则
16. 新去重规则
17. 新取最新/取第一条规则
18. 新分组字段
19. 新条件分支
20. 新业务规则
21. 新 Java 实现约束

处理规则：

- 有明确依据：写入对应规则，并引用 Evidence ID。
- 无明确依据：不得新增，登记为 Unknown。
- 只是工程建议：写为 suggestion，不得作为 hard。

Phase2 不得基于本防护栏新增评审标准；本防护栏只用于阻止模型生成额外问题。

---

# Deterministic Output

相同输入必须输出相同结构、相同章节、相同编号顺序。

## 章节顺序

Phase1：

1. `# 标准加工规范 — <因子名>`
2. `## 0. 输入解析`
3. `## 因子加工输入字段`
4. `## 字段溯源`
5. `## 过滤条件`
6. `## 列表/数组字段处理`
7. `## 计算逻辑`
8. `## 默认值兜底策略`
9. `## 因子输出字段`
10. `## 比率/衍生因子计算`
11. `## 条件分支逻辑`
12. `## Unknown Register`

Phase2：

1. `# 评审报告 — <因子名>`
2. `## 0. 输入解析`
3. `## 总体结论`
4. `## 汇总问题清单`
5. `## 待确认项`

## Rule ID

统一使用 D 编号：D1-001 至 D9-999。禁止生成 `F-001`、`L-003`、`A-002`、`T-001` 等不稳定编号。

## 排序

当存在多个合理排序时，按以下顺序：

1. D 编号升序
2. Rule ID 升序
3. 字段路径字典序
4. 原文出现顺序

不得使用随机表达：若干、相关、等等、视情况、一般、通常、建议可适当。

---

# Unknown Register

凡缺少明确依据但会影响字段集合、过滤范围、聚合对象、计算口径、默认值路径或最终数值含义的内容，必须登记 Unknown，不得补成 hard。

| Unknown ID | 触发位置 | 未知内容 | 原因 | 影响 | 处理方式 |
|---|---|---|---|---|---|

编号规则：

- Unknown ID 使用 `U-D章节号-三位序号`。
- 例如 `U-D3-001`、`U-D5-001`、`U-D9-001`。
- 无 Unknown 时保留表头，并在表格后写「无」。

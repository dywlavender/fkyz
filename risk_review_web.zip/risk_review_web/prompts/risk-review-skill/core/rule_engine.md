# Rule Engine

## Rule Level

| Level | 含义 | Phase1 用法 | Phase2 用法 |
|---|---|---|---|
| hard | 有明确依据或确定性推导 | 写入标准规则 | 可作为不符合依据 |
| unclear | 未明确、待确认 | 写入 Unknown | 不作为问题依据 |
| suggestion | 非阻断建议 | 只作为建议 | 不作为问题依据 |

## Basis Type

| basis_type | 含义 |
|---|---|
| requirement | 需求内容 |
| api_doc | 接口文档 |
| public_rule | 公共业务规则 |
| deterministic_inference | 确定性推导 |
| unbased_suggestion | 无依据建议 |

## Rule JSON Contract

每条规则必须包含：

- `rule_id`
- `dimension_ref`
- `source_section`
- `standard_level`
- `basis_type`
- `evidence_ids`
- `content`

`standard_level = unclear` 和 `standard_level = suggestion` 不得作为 Phase2 的 `❌ 不符合` 依据。
